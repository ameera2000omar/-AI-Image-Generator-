import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Loader2 } from 'lucide-react';

const ImageGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [resolution, setResolution] = useState('1024x1024');
  const [style, setStyle] = useState('Realistic');

  const generateImage = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, resolution, style })
      });
      const data = await res.json();
      setImageUrl(data.imageUrl);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 p-8">
      <Card className="w-full max-w-xl">
        <CardContent>
          <Input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="اكتب وصفًا للصورة..."
            className="w-full mb-4"
          />
          <select
            value={resolution}
            onChange={(e) => setResolution(e.target.value)}
            className="w-full mb-4 p-2 rounded-lg border"
          >
            <option value="512x512">512x512</option>
            <option value="1024x1024">1024x1024</option>
            <option value="2048x2048">2048x2048</option>
          </select>
          <select
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            className="w-full mb-4 p-2 rounded-lg border"
          >
            <option value="Realistic">واقعي</option>
            <option value="Artistic">فني</option>
            <option value="Cartoon">كرتوني</option>
            <option value="Abstract">مجرد</option>
          </select>
          <Button onClick={generateImage} disabled={loading} className="w-full">
            {loading ? <Loader2 className="animate-spin mr-2" /> : 'إنشاء الصورة'}
          </Button>
        </CardContent>
      </Card>
      {imageUrl && (
        <div className="w-full max-w-xl mt-6">
          <img src={imageUrl} alt="Generated" className="w-full rounded-2xl shadow-lg" />
        </div>
      )}
    </div>
  );
};

export default ImageGenerator;
