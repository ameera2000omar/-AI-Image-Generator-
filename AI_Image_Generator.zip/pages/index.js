import React from 'react';
import ImageGenerator from '../components/ImageGenerator';

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gray-50">
      <h1 className="text-3xl font-bold mb-8">مولّد الصور بالذكاء الاصطناعي</h1>
      <ImageGenerator />
    </main>
  );
}
