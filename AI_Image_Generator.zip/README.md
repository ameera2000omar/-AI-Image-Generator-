# AI Image Generator

مولّد صور يستخدم Next.js و OpenAI Image API

## المتطلبات
- Node.js v16+
- مفتاح API من OpenAI (ضَعُه في ملف .env.local كـ `OPENAI_API_KEY=`)

## التثبيت
```bash
npm install
```

## التشغيل محليًا
```bash
npm run dev
```

ثم افتح المتصفح على `http://localhost:3000`
